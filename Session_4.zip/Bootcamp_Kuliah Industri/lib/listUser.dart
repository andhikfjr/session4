import 'package:flutter/material.dart';
import 'appBar.dart';
import 'userData.dart';

class listUser extends StatelessWidget {
  const listUser({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MyAppBar(),
      backgroundColor: Colors.pink,
      body: Padding(
        padding: const EdgeInsets.only(top: 20.0),
        child: UserData.userList.isEmpty
            ? const Center(
          child: Text(
            'Belum ada data pengguna',
            style: TextStyle(
              fontFamily: 'Poppins',
              fontWeight: FontWeight.w400,
              color: Colors.white,
            ),
          ),
        )
            : ListView.builder(
          itemCount: UserData.userList.length,
          itemBuilder: (context, index) {
            final user = UserData.userList[index];
            final username = user['username'] ?? '';
            final namaLengkap = user['namalengkap'] ?? '';

            return Card(
              margin: const EdgeInsets.symmetric(
                  horizontal: 16, vertical: 8),
              color: Colors.white,
              elevation: 2,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Data ke - ${index + 1}',
                      style: const TextStyle(
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w600,
                        fontSize: 16,
                        color: Colors.black,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Username : $username',
                      style: const TextStyle(
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w400,
                        color: Colors.black,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Nama Lengkap : $namaLengkap',
                      style: const TextStyle(
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w400,
                        color: Colors.black,
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}