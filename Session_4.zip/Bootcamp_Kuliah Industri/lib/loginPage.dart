import 'package:flutter/material.dart';
import 'userData.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  String _message = '';
  Color _messageColor = Colors.green;

  void _showMessage(String message, Color color) {
    setState(() {
      _message = message;
      _messageColor = color;
    });
  }

  void _checkLogin() {
    if (_formKey.currentState!.validate()) {
      String inputUsername = _usernameController.text;
      String inputPassword = _passwordController.text;

      bool isValid = UserData.userList.any((user) =>
      user['username'] == inputUsername && user['password'] == inputPassword);

      if (isValid) {
        _showMessage("Berhasil login", Colors.green);
      } else {
        _showMessage("Login gagal. Username atau password salah.", Colors.white);
      }
    } else {
      _showMessage("Username dan Password tidak boleh kosong", Colors.white);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Halaman Login'),
        backgroundColor: Colors.pink,
      ),
      backgroundColor: Colors.pink,
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _usernameController,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.white,
                  labelText: 'Username',
                  hintText: 'Masukkan username anda',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: BorderSide.none,
                  ),
                ),
                validator: (value) =>
                value == null || value.isEmpty ? 'Username tidak boleh kosong' : null,
              ),

              const SizedBox(height: 20),
              TextFormField(
                controller: _passwordController,
                obscureText: true,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.white,
                  labelText: 'Password',
                  hintText: 'Masukkan password anda',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: BorderSide.none,
                  ),
                ),
                validator: (value) =>
                value == null || value.isEmpty ? 'Password tidak boleh kosong' : null,
              ),

              const SizedBox(height: 20),
              Center(
                child: ElevatedButton(
                  onPressed: _checkLogin,
                  child: const Text(
                    'LOGIN',
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w600,
                      color: Colors.black,
                    ),
                  ),
                  style: OutlinedButton.styleFrom(
                    fixedSize: const Size(200, 40),
                  ),
                ),
              ),

              if (_message.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 20),
                  child: Text(
                    _message,
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      color: _messageColor,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
