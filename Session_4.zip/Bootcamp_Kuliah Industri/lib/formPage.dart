import 'package:flutter/material.dart';
import 'appBar.dart';
import 'userData.dart';

class formPage extends StatefulWidget {
  const formPage({super.key});

  @override
  State<formPage> createState() => _FormPageState();
}

class _FormPageState extends State<formPage> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _namalengkapController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  String _message = '';
  Color _messageColor = Colors.green;

  void _showMessage(String message, Color color) {
    setState(() {
      _message = message;
      _messageColor = color;
    });
  }
  void _handleSubmit() {
    if (_formKey.currentState!.validate()) {
      UserData.userList.add({
        'username': _usernameController.text,
        'namalengkap': _namalengkapController.text,
        'password': _passwordController.text,
      });
      _usernameController.clear();
      _namalengkapController.clear();
      _passwordController.clear();
      _showMessage('Data berhasil disimpan', Colors.green);
    } else {
      _showMessage('Data tidak boleh kosong', Colors.white);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MyAppBar(),
      backgroundColor: Colors.pink,
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              // Username Field
              TextFormField(
                controller: _usernameController,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: BorderSide.none,
                  ),
                  labelText: 'Username',
                  hintText: 'Masukkan username anda',
                ),
                validator: (value) => value == null || value.isEmpty ? 'Username tidak boleh kosong' : null,
              ),
              const SizedBox(height: 20),

              // Nama Lengkap Field
              TextFormField(
                controller: _namalengkapController,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: BorderSide.none,
                  ),
                  labelText: 'Nama lengkap',
                  hintText: 'Masukkan nama lengkap anda',
                ),
                validator: (value) => value == null || value.isEmpty ? 'Nama lengkap tidak boleh kosong' : null,
              ),
              const SizedBox(height: 20),

              // Password Field
              TextFormField(
                controller: _passwordController,
                obscureText: true,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: BorderSide.none,
                  ),
                  labelText: 'Password',
                  hintText: 'Masukkan password anda',
                ),
                validator: (value) => value == null || value.isEmpty ? 'Password tidak boleh kosong' : null,
              ),
              const SizedBox(height: 20),

              // Submit Button
              Center(
                child: ElevatedButton(
                  onPressed: _handleSubmit,
                  child: const Text(
                    'SUBMIT',
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w600,
                      color: Colors.black,
                    ),
                  ),
                  style: OutlinedButton.styleFrom(
                    fixedSize: const Size(200, 40),
                  ),
                ),
              ),

              if (_message.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 20),
                  child: Text(
                    _message,
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      color: _messageColor,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
